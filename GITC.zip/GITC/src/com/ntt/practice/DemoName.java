package com.ntt.practice;

import java.util.*;

public class DemoName {
	public static void main(String[] args) {
		String name;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enetr name");		
		name = sc.nextLine();
		System.out.println("Entered name is : "+name);		
	}

}
