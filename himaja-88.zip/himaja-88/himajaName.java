package com.ntt.practice;

import java.util.Scanner;

public class DemoName {
	public static void main(String[] args) {
		String name;
		Scanner sc = new Scanner(System.in);
		
		name = sc.nextLine();
		System.out.println("Name is : "+name);		
	}

}
